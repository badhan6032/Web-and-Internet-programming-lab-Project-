<div id="footer">
    <h2 style="text-align: center; padding-top: 30px;">&copy Shakib Hossain, Roktim Paul Mishal, Asfat Khan Nadim, Shahriar Badhan. </h2>
</div>