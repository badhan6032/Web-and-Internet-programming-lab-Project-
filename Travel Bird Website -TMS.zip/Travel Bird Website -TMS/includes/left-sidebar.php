<div class="sidebar">
    <div id="sidebar_title"><b>Categories</b></div>
    <ul id="cats">
        <?php getCats(); ?>
    </ul>
    <br>
    <div id="sidebar_title"><b>Types</b></div>
    <ul id="cats">
        <?php getTypes(); ?>
    </ul>
</div>